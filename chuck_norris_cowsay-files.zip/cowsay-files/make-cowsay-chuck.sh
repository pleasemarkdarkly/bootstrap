#!/bin/bash

# ANSI art (eg colored cows) don't render in txt or markdown. oh well.


files=(~/Developer/dotfiles/cowsay-files/cows/*cow);cowsay -f `printf "%s\n" "${files[RANDOM % ${#files}]}"` "`~/.chuck_norris.sh`"



#for cowfile in cows/*cow; do
#  cowname=$(basename $cowfile)
#  echo "## ${cowname}"
#  echo ""
#  echo '```'

#  cowsay -f ${cowfile} -- "$cowname"

#  echo '```'
#  echo ""
#done

